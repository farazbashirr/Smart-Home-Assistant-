import  speech_recognition as sr
import pyttsx3
import numpy as np
import random

# Initialize text-to-speech engine
engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Adjust the speaking rate

def speak(text):
    """Converts text to speech."""
    engine.say(text)
    engine.runAndWait()
def recognize_speech():
    """Listens for a voice command."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        speak("How can I assist you?")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
            command = recognizer.recognize_google(audio)
            print(f"You said: {command}")
            return command.lower()
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that.")
            return None
        except sr.RequestError:
            speak("Network error. Please try again later.")
            return None
        except Exception as e:
            speak(f"An error occurred: {str(e)}")
            return None

def authenticate_pin():
    """Authenticate the user using a PIN password."""
    valid_pins = {"1524": "Jaweria", "1234": "Faraz", "1122": "Mudassir", "0000": "Hafsa"}
    speak("Please enter your PIN.")
    pin = input("Enter PIN: ")
    if pin in valid_pins:
        speak(f"Welcome {valid_pins[pin]}.")
        return True
    else:
        speak("Invalid PIN. Access denied.")
        return False

def authenticate_fingerprint():
    """Placeholder for fingerprint authentication."""
    speak("Fingerprint scanner is not connected. Bypassing for now.")
    return False

def authenticate_camera():
    """Placeholder for camera recognition authentication."""
    speak("Camera recognition is not connected. Bypassing for now.")
    return False

# Genetic Algorithm for optimizing energy management
def genetic_algorithm(pop_size, num_generations, num_devices, hours):
    """Optimize device schedules using a genetic algorithm."""
    # Initialize random population
    population = [np.random.randint(2, size=(num_devices, hours)) for _ in range(pop_size)]
    
    def fitness(schedule):
        """Calculate the fitness of a schedule."""
        total_energy = np.sum(schedule)
        penalty = 0
        for device in range(num_devices):
            if not (6 <= np.argmax(schedule[device]) <= 22):  # Ensure devices mostly run during daytime
                penalty += 5  # Penalty for violating preferences
        return 1 / (1 + total_energy + penalty)

    def select_parents(population):
        """Select two parents using roulette wheel selection."""
        fitness_values = [fitness(ind) for ind in population]
        probabilities = fitness_values / np.sum(fitness_values)
        parents = random.choices(population, weights=probabilities, k=2)
        return parents

    def crossover(parent1, parent2):
        """Perform single-point crossover."""
        point = random.randint(1, hours - 1)
        child1 = np.vstack((parent1[:, :point], parent2[:, point:]))
        child2 = np.vstack((parent2[:, :point], parent1[:, point:]))
        return child1, child2

    def mutate(child):
        """Mutate a random bit in the child's schedule."""
        device = random.randint(0, num_devices - 1)
        hour = random.randint(0, hours - 1)
        child[device, hour] = 1 - child[device, hour]
        return child

    # Run the genetic algorithm
    for generation in range(num_generations):
        new_population = []
        for _ in range(pop_size // 2):
            parent1, parent2 = select_parents(population)
            child1, child2 = crossover(parent1, parent2)
            if random.random() < 0.1:  # Mutation rate
                child1 = mutate(child1)
            if random.random() < 0.1:
                child2 = mutate(child2)
            new_population.extend([child1, child2])
        population = new_population

    # Return the best solution
    best_schedule = max(population, key=fitness)
    return best_schedule

def optimize_energy():
    """Optimize device schedules using the genetic algorithm."""
    speak("Optimizing energy usage. Please wait.")
    num_devices = 3  # Example: Lights, heating, and fan
    hours = 24  # 24-hour schedule
    pop_size = 10
    num_generations = 50

    # Run the genetic algorithm
    best_schedule = genetic_algorithm(pop_size, num_generations, num_devices, hours)

    # Display the optimized schedule
    for device, schedule in enumerate(best_schedule):
        schedule_str = ''.join(['On' if hour else 'Off' for hour in schedule])
        print(f"Device {device + 1} schedule: {schedule_str}")
        speak(f"Device {device + 1} schedule: {schedule_str}")

def handle_command(command):
    """Processes the user's voice command."""
    if command is None:
        return

    # Lights control
    if "turn on the lights" in command:
        speak("Turning on the lights.")
        print("Now lights are on")
        speak("Now lights are on")
    elif "turn off the lights" in command:
        speak("Turning off the lights.")
        print("Now lights are off")
        speak("Now lights are off")

    # Security system
    elif "lock the doors" in command:
        speak("Locking the doors.")
        print("Now door is locked")
        speak("Now door is locked")
    elif "unlock the doors" in command:
        speak("Unlocking the doors.")
        print("Now door is unlocked")
        speak("Now door is unlocked")

    # Energy optimization
    elif "optimize energy" in command:
        optimize_energy()

    # Default response
    else:
        speak("I didn't understand that command. Please try again.")

# Main loop
if __name__ == "_main_":
    speak("Smart Home Assistant is ready.")

    while True:
        if authenticate_pin():
            user_command = recognize_speech()
            if user_command and "exit" in user_command:
                speak("Goodbye!")
                break
            handle_command(user_command)
        elif authenticate_fingerprint():
            user_command = recognize_speech()
            if user_command and "exit" in user_command:
                speak("Goodbye!")
                break
            handle_command(user_command)
        elif authenticate_camera():
            user_command = recognize_speech()
            if user_command and "exit" in user_command:
                speak("Goodbye!")
                break
            handle_command(user_command)
        else:
            speak("Access denied. Goodbye.")